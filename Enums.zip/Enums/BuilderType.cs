﻿namespace ChartAPI.Enums
{
    public enum BuilderType
    {
        BooleanSqlBuilder,
        EqualSqlBuilder,
        InSqlBuilder,
        LikeSqlBuilder

    }
}
