﻿using ChartAPI.DataAccess.Interfaces;
using ChartAPI.DataAccess.SQLite.Repositories;
using ChartAPI.Models;
using ChartAPI.Models.Filters;

namespace ChartAPI.Services.Queries
{
    public class ManHourQueryService : IManHourQueryService
    {
        private IManHourRepository _dataRepository = new ManHourRepository();

        public ManHourQueryService()
        {

        }

        List<ManHourModel> IManHourQueryService.GetByFilter(IFilter filter)
        {
            return _dataRepository.GetByFilterAsync(filter).ToList();
        }
    }
}
