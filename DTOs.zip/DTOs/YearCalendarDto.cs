﻿namespace ChartAPI.DTOs
{
    public class YearCalendarDto
    {
        public int Year { get; set; }
        public List<object[]> Data { get; set; }
    }
}
