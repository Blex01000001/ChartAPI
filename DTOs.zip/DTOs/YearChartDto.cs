﻿namespace ChartAPI.DTOs
{
    public class YearChartDto
    {
        public void Build()
        {

        }
    }
}
