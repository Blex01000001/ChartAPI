﻿namespace ChartAPI.ChartBuilders
{
    public interface IAnnualSummaryBuilder
    {
    }
}
