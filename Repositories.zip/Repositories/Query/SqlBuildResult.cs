﻿using System.Data.SQLite;

namespace ChartAPI.Repositories.Query
{
    /// <summary>
    /// 每個欄位一個 Builder 回傳的小結果：SQL 片段 + 對應參數
    /// </summary>
    public class SqlBuildResult
    {
        public string SqlFragment { get; set; } = string.Empty;
        public List<SQLiteParameter> Parameters { get; set; } = new();
    }
}
