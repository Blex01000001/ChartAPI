﻿namespace ChartAPI.Repositories.Query
{
    /// <summary>
    /// 所有 SQL Builder 的共同介面
    /// </summary>
    public interface ISqlBuilder
    {
        SqlBuildResult Build(string key, object value);
    }
}
