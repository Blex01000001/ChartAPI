﻿namespace ChartAPI.Repositories.Filters
{
    public abstract class BaseFilter : IFilter
    {
        protected readonly Dictionary<string, object> _fields = new();

        public virtual BaseFilter Set(string key, object value)
        {
            if (value == null)
                return this;

            _fields[key] = value;
            return this;
        }

        public T TryGet<T>(string key)
        {
            if (_fields.TryGetValue(key, out var value) && value is T typed)
                return typed;

            return default(T);
        }

        public Dictionary<string, object> GetRawFields() => _fields;
    }
}
