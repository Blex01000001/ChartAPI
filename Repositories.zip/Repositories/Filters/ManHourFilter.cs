﻿namespace ChartAPI.Repositories.Filters
{
    public class ManHourFilter : BaseFilter
    {
        public List<string> Name
        {
            get => TryGet<List<string>>(nameof(Name)) ?? new();
            set => Set(nameof(Name), value);
        }

        public List<string> ID
        {
            get => TryGet<List<string>>(nameof(ID)) ?? new();
            set => Set(nameof(ID), value);
        }

        public List<string> CostCode
        {
            get => TryGet<List<string>>(nameof(CostCode)) ?? new();
            set => Set(nameof(CostCode), value);
        }

        public DateTime? DateFrom
        {
            get => TryGet<DateTime?>(nameof(DateFrom));
            set => Set(nameof(DateFrom), value);
        }

        public DateTime? DateTo
        {
            get => TryGet<DateTime?>(nameof(DateTo));
            set => Set(nameof(DateTo), value);
        }

        public List<int> Year
        {
            get => TryGet<List<int>>(nameof(Year)) ?? new();
            set => Set(nameof(Year), value);
        }

        public List<int> Month
        {
            get => TryGet<List<int>>(nameof(Month)) ?? new();
            set => Set(nameof(Month), value);
        }

        public List<string> Group2
        {
            get => TryGet<List<string>>(nameof(Group2)) ?? new();
            set => Set(nameof(Group2), value);
        }
    }
}
