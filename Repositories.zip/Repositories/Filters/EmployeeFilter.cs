﻿namespace ChartAPI.Repositories.Filters
{
    public class EmployeeFilter : BaseFilter
    {
        public List<string> employee_id
        {
            get => TryGet<List<string>>(nameof(employee_id)) ?? new();
            set => Set(nameof(employee_id), value);
        }

        public List<string> employee_name
        {
            get => TryGet<List<string>>(nameof(employee_name)) ?? new();
            set => Set(nameof(employee_name), value);
        }

        public List<string> Group2
        {
            get => TryGet<List<string>>(nameof(Group2)) ?? new();
            set => Set(nameof(Group2), value);
        }

        public string Position
        {
            get => TryGet<string>(nameof(Position));
            set => Set(nameof(Position), value);
        }

        public string Dept
        {
            get => TryGet<string>(nameof(Dept));
            set => Set(nameof(Dept), value);
        }
    }
}
