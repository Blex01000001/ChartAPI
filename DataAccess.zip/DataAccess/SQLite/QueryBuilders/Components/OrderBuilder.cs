﻿namespace ChartAPI.DataAccess.SQLite.QueryBuilders.Components
{
    public class OrderBuilder
    {
        private readonly List<string> _orders = new();

        public void Add(string field, bool desc) { }

        //public string Build() { ... }
    }
}
