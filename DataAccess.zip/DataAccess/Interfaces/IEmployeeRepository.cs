﻿using ChartAPI.Models;

namespace ChartAPI.DataAccess.Interfaces
{
    public interface IEmployeeRepository : IRepository<EmployeeModel>
    {
    }
}
