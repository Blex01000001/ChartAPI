﻿namespace ChartAPI.Models
{
    public class EmployeeFilter
    {
        public List<string> id { get; } = new List<string>();
        public List<string> employee_id { get; } = new List<string>();
        public List<string> employee_name { get; } = new List<string>();
        public List<string> position { get; } = new List<string>();
        public List<string> cost_center_desc { get; } = new List<string>();
        public List<string> org_id { get; } = new List<string>();
        public List<string> prj_id { get; } = new List<string>();
        public List<string> org_pid { get; } = new List<string>();
        public List<string> img { get; } = new List<string>();
        public List<string> is_mgr { get; } = new List<string>();
        public List<string> is_Assistant { get; } = new List<string>();
        public List<string> SearchPersonDetailLink { get; } = new List<string>();
        public List<string> ext_no { get; } = new List<string>();
        public List<string> tags { get; } = new List<string>();
        public List<string> Group1 { get; } = new List<string>();
        public List<string> Group2 { get; } = new List<string>();
        public List<string> Group3 { get; } = new List<string>();
        public List<string> Group4 { get; } = new List<string>();
    }
}
